package org.Queue;

public class QueueArray {
    static int[] arr=new int[6];

    static int end=0;
}
