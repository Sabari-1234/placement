package org.StackDynamic;

public class StackArray {

    static  int top=0;
    static int size=2;
    static int[] arr=new int[size];
}
