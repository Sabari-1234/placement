package org.SLL;

public class Node {
    int data;
    Node next;
    public static Node head=null;
    public Node(int data) {
        this.next = null;
        this.data = data;
    }

}
