package org.QueueDynamic;

public class QueueArray {
    static int size=2;
    static int[] arr=new int[size];
    static int end=0;
}
