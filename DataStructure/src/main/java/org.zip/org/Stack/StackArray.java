package org.Stack;

public class StackArray {
    static int[] arr=new int[6];
    static  int top=0;
}
